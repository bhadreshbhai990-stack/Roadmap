# Road Map (Android, Kotlin + Jetpack Compose)

Ad-free vehicle info app. Original code, name and logo.

## Run
1. Android Studio (Ladybug or newer) -> Open this folder -> let Gradle sync.
2. Run on device/emulator. With no API key the app runs in DEMO mode (sample data).

## Real data
1. Pick a licensed vehicle-data API provider.
2. Copy `local.properties.example` to `local.properties`, set API_BASE_URL and API_KEY.
3. Edit the path in `Api` and the key names in `ApiProvider.pick(...)` (data/Providers.kt).

## Features
Vehicle lookup by number, details (class, fuel, reg date, RTO, insurance/fitness/PUC, weight),
save/remove vehicles (Room), PDF report + share, no ads, no trackers.

## Logo
res/drawable/ic_logo_fg.xml + ic_logo_bg.xml (adaptive icon): white map pin on navy, amber road.
Colors: Navy #0B3D91, Amber #FFB300.

## Login (WhatsApp OTP + Truecaller)
**Truecaller** (OAuth SDK 3.0.0): create a project at developer.truecaller.com, get a Client ID, add
`TRUECALLER_CLIENT_ID=...` to local.properties. Requires the Truecaller app on the user's phone; add your
app's package name + signing SHA-1 in the Truecaller portal. Scopes used: profile, phone, openid.
If an import under `com.truecaller.android.sdk.oAuth` does not resolve, check the SDK docs for your version.

**WhatsApp OTP**: WhatsApp has no "Login with WhatsApp" SDK. You need a small backend that sends the OTP via the
WhatsApp Business Cloud API (authentication template). Set `OTP_BASE_URL=https://your-backend/` and implement:
- `POST auth/whatsapp/send`   body `{"phone":"91XXXXXXXXXX"}`  -> 200 if sent
- `POST auth/whatsapp/verify` body `{"phone":"...","code":"123456"}` -> 200 if correct, else 4xx
Keep the Meta token on the server only; hash OTPs, expire them in ~5 min, rate-limit sends.
With `OTP_BASE_URL` blank the app runs in DEMO mode (OTP = 123456).

package com.roadmap.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.fragment.app.FragmentActivity
import com.roadmap.app.data.TruecallerLogin
import com.roadmap.app.ui.AppViewModel
import com.roadmap.app.ui.RoadMapApp
import com.roadmap.app.ui.RoadMapTheme

// Truecaller SDK needs a FragmentActivity.
class MainActivity : FragmentActivity() {
    private val vm: AppViewModel by viewModels()
    private lateinit var truecaller: TruecallerLogin

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        truecaller = TruecallerLogin(this, onPhone = vm::login, onError = vm::loginError)
        truecaller.init()
        setContent { RoadMapTheme { RoadMapApp(vm, onTruecaller = truecaller::start) } }
    }

    @Deprecated("Required by Truecaller SDK")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        truecaller.onActivityResult(requestCode, resultCode, data)
    }
}

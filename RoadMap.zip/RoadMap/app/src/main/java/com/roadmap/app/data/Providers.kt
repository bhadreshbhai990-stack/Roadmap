package com.roadmap.app.data

import com.roadmap.app.BuildConfig
import kotlinx.coroutines.delay
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Path

interface VehicleProvider {
    suspend fun lookup(regNo: String): Result<VehicleInfo>
}

/** Runs without any API so you can test the whole app. Replace with a licensed provider. */
object DemoProvider : VehicleProvider {
    override suspend fun lookup(regNo: String): Result<VehicleInfo> {
        delay(700)
        return Result.success(
            VehicleInfo(
                regNo = regNo, ownerName = "DEMO OWNER", makerModel = "DEMO MOTORS / SAMPLE 1.2",
                vehicleClass = "Motor Car (LMV)", fuelType = "Petrol", registrationDate = "01-Jan-2020",
                rtoOffice = "Demo RTO", insuranceUpto = "31-Dec-2026", fitnessUpto = "31-Dec-2034",
                pucUpto = "30-Jun-2027", grossWeight = "1450 kg"
            )
        )
    }
}

private interface Api {
    @GET("vehicle/{reg}")
    suspend fun get(@Path("reg") reg: String, @Header("Authorization") key: String): Map<String, Any?>
}

/**
 * Generic REST provider. Adjust the path in [Api] and the key names in [pick]
 * to match the licensed vehicle-data API you choose.
 */
object ApiProvider : VehicleProvider {
    private val api: Api by lazy {
        Retrofit.Builder().baseUrl(BuildConfig.API_BASE_URL)
            .addConverterFactory(GsonConverterFactory.create()).build().create(Api::class.java)
    }

    private fun Map<String, Any?>.pick(vararg keys: String): String =
        keys.firstNotNullOfOrNull { k -> this[k]?.toString()?.takeIf { it.isNotBlank() } } ?: "-"

    override suspend fun lookup(regNo: String): Result<VehicleInfo> = runCatching {
        val m = api.get(regNo, "Bearer ${BuildConfig.API_KEY}")
        VehicleInfo(
            regNo = regNo,
            ownerName = m.pick("owner_name", "owner"),
            makerModel = m.pick("maker_model", "model"),
            vehicleClass = m.pick("vehicle_class", "class"),
            fuelType = m.pick("fuel_type", "fuel"),
            registrationDate = m.pick("registration_date", "reg_date"),
            rtoOffice = m.pick("rto", "registered_at"),
            insuranceUpto = m.pick("insurance_upto"),
            fitnessUpto = m.pick("fitness_upto"),
            pucUpto = m.pick("puc_upto"),
            grossWeight = m.pick("gross_weight")
        )
    }
}

fun activeProvider(): VehicleProvider =
    if (BuildConfig.API_KEY.isBlank()) DemoProvider else ApiProvider

private val REG = Regex("^[A-Z]{2}[0-9]{1,2}[A-Z]{0,3}[0-9]{4}$")
fun normalizeReg(raw: String): String? =
    raw.uppercase().filter { it.isLetterOrDigit() }.takeIf { REG.matches(it) }

package com.roadmap.app.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import com.roadmap.app.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class AuthState(val busy: Boolean = false, val otpSent: Boolean = false, val phone: String = "", val error: String? = null)

data class SearchState(val loading: Boolean = false, val error: String? = null)

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = Room.databaseBuilder(app, AppDb::class.java, "roadmap.db").build().dao()
    val saved: StateFlow<List<VehicleInfo>> =
        dao.all().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _state = MutableStateFlow(SearchState())
    val state: StateFlow<SearchState> = _state

    fun search(raw: String, onResult: (VehicleInfo) -> Unit) {
        val reg = normalizeReg(raw)
        if (reg == null) { _state.value = SearchState(error = "Enter a valid vehicle number, e.g. GJ05AB1234"); return }
        viewModelScope.launch {
            _state.value = SearchState(loading = true)
            activeProvider().lookup(reg)
                .onSuccess { _state.value = SearchState(); onResult(it) }
                .onFailure { _state.value = SearchState(error = "Could not fetch details. Check internet / API key.") }
        }
    }

    fun toggleSave(v: VehicleInfo, isSaved: Boolean) {
        viewModelScope.launch { if (isSaved) dao.delete(v.regNo) else dao.save(v.copy(savedAt = System.currentTimeMillis())) }
    }

    // ---- login ----
    private val prefs = app.getSharedPreferences("session", Context.MODE_PRIVATE)
    private val _phone = MutableStateFlow(prefs.getString("phone", null))
    val phone: StateFlow<String?> = _phone
    private val _auth = MutableStateFlow(AuthState())
    val auth: StateFlow<AuthState> = _auth

    fun login(p: String) { prefs.edit().putString("phone", p).apply(); _phone.value = p; _auth.value = AuthState() }
    fun logout() { prefs.edit().remove("phone").apply(); _phone.value = null; _auth.value = AuthState() }
    fun loginError(msg: String) { _auth.update { it.copy(busy = false, error = msg) } }
    fun resetOtp() { _auth.value = AuthState() }

    fun sendOtp(raw: String) {
        val p = normalizePhone(raw) ?: return loginError("Enter a valid mobile number")
        viewModelScope.launch {
            _auth.value = AuthState(busy = true, phone = p)
            otpProvider().send(p)
                .onSuccess { _auth.value = AuthState(otpSent = true, phone = p) }
                .onFailure { _auth.value = AuthState(phone = p, error = "Could not send OTP. Try again.") }
        }
    }

    fun verifyOtp(code: String) {
        val p = _auth.value.phone
        viewModelScope.launch {
            _auth.update { it.copy(busy = true, error = null) }
            otpProvider().verify(p, code.trim())
                .onSuccess { login(p) }
                .onFailure { _auth.update { it.copy(busy = false, error = "Wrong or expired OTP") } }
        }
    }
}

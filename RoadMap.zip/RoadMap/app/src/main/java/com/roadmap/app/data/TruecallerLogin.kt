package com.roadmap.app.data

import android.content.Intent
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import com.roadmap.app.BuildConfig
import com.truecaller.android.sdk.oAuth.CodeVerifierUtil
import com.truecaller.android.sdk.oAuth.TcOAuthCallback
import com.truecaller.android.sdk.oAuth.TcOAuthData
import com.truecaller.android.sdk.oAuth.TcOAuthError
import com.truecaller.android.sdk.oAuth.TcSdk
import com.truecaller.android.sdk.oAuth.TcSdkOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.math.BigInteger
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.SecureRandom

/** Truecaller OAuth SDK 3.0 flow: consent -> auth code -> token -> userinfo (phone number). */
class TruecallerLogin(
    private val activity: FragmentActivity,
    private val onPhone: (String) -> Unit,
    private val onError: (String) -> Unit
) {
    private var ready = false
    private var state = ""
    private var verifier = ""

    private val callback = object : TcOAuthCallback {
        override fun onSuccess(tcOAuthData: TcOAuthData) {
            if (tcOAuthData.state != state) { onError("Security check failed. Try again."); return }
            activity.lifecycleScope.launch {
                runCatching { withContext(Dispatchers.IO) { fetchPhone(tcOAuthData.authorizationCode) } }
                    .onSuccess { onPhone(it) }
                    .onFailure { onError("Truecaller login failed. Use WhatsApp OTP.") }
            }
        }
        override fun onFailure(tcOAuthError: TcOAuthError) {
            onError(tcOAuthError.errorMessage ?: "Truecaller login cancelled")
        }
    }

    fun init() {
        if (BuildConfig.TRUECALLER_CLIENT_ID.isBlank()) return
        TcSdk.init(TcSdkOptions.Builder(activity, callback).build())
        ready = TcSdk.getInstance().isOAuthFlowUsable
    }

    fun start() {
        if (BuildConfig.TRUECALLER_CLIENT_ID.isBlank()) { onError("Truecaller is not configured yet. Use WhatsApp OTP."); return }
        if (!ready) { onError("Truecaller app not found on this phone. Use WhatsApp OTP."); return }
        val sdk = TcSdk.getInstance()
        state = BigInteger(130, SecureRandom()).toString(32)
        sdk.setOAuthState(state)
        sdk.setOAuthScopes(arrayOf("profile", "phone", "openid"))
        verifier = CodeVerifierUtil.generateRandomCodeVerifier()
        val challenge = CodeVerifierUtil.getCodeChallenge(verifier)
        if (challenge == null) { onError("This device is not supported for Truecaller login."); return }
        sdk.setCodeChallenge(challenge)
        sdk.getAuthorizationCode(activity)
    }

    fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (ready && requestCode == TcSdk.SHARE_PROFILE_REQUEST_CODE)
            TcSdk.getInstance().onActivityResultObtained(activity, requestCode, resultCode, data)
    }

    private fun fetchPhone(code: String): String {
        fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
        val body = "grant_type=authorization_code&client_id=${enc(BuildConfig.TRUECALLER_CLIENT_ID)}" +
            "&code=${enc(code)}&code_verifier=${enc(verifier)}"
        val t = (URL("https://oauth-account-noneu.truecaller.com/v1/token").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; doOutput = true
            setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            outputStream.use { it.write(body.toByteArray()) }
        }
        val token = JSONObject(t.inputStream.bufferedReader().readText()).getString("access_token")
        val u = (URL("https://oauth-account-noneu.truecaller.com/v1/userinfo").openConnection() as HttpURLConnection).apply {
            setRequestProperty("Authorization", "Bearer $token")
        }
        return JSONObject(u.inputStream.bufferedReader().readText()).getString("phone_number")
    }
}

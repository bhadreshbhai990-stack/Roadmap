package com.roadmap.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "saved_vehicles")
data class VehicleInfo(
    @PrimaryKey val regNo: String,
    val ownerName: String = "-",
    val makerModel: String = "-",
    val vehicleClass: String = "-",
    val fuelType: String = "-",
    val registrationDate: String = "-",
    val rtoOffice: String = "-",
    val insuranceUpto: String = "-",
    val fitnessUpto: String = "-",
    val pucUpto: String = "-",
    val grossWeight: String = "-",
    val savedAt: Long = System.currentTimeMillis()
)

@Dao
interface VehicleDao {
    @Query("SELECT * FROM saved_vehicles ORDER BY savedAt DESC")
    fun all(): Flow<List<VehicleInfo>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun save(v: VehicleInfo)
    @Query("DELETE FROM saved_vehicles WHERE regNo = :reg")
    suspend fun delete(reg: String)
}

@Database(entities = [VehicleInfo::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): VehicleDao
}

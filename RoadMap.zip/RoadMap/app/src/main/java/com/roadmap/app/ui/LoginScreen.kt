package com.roadmap.app.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.roadmap.app.R
import com.roadmap.app.data.isOtpDemo

private val WhatsAppGreen = Color(0xFF25D366)

@Composable
fun LoginScreen(
    auth: AuthState,
    onSend: (String) -> Unit,
    onVerify: (String) -> Unit,
    onChangeNumber: () -> Unit,
    onTruecaller: () -> Unit
) {
    var phone by rememberSaveable { mutableStateOf("") }
    var code by rememberSaveable { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize().background(Bg).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(48.dp))
        Box(Modifier.size(96.dp).clip(CircleShape).background(Navy), contentAlignment = Alignment.Center) {
            Image(painterResource(R.drawable.ic_logo_fg), null, Modifier.size(90.dp))
        }
        Spacer(Modifier.height(12.dp))
        Text("Road Map", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Navy)
        Text("Log in to continue", color = Color.Gray)
        Spacer(Modifier.height(28.dp))

        if (!auth.otpSent) {
            OutlinedTextField(
                value = phone, onValueChange = { phone = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                label = { Text("Mobile number") }, prefix = { Text("+91 ") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
            )
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = { onSend(phone) }, enabled = !auth.busy,
                modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = WhatsAppGreen, contentColor = Color.White)
            ) {
                if (auth.busy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp, color = Color.White)
                else Text("Send OTP on WhatsApp", fontWeight = FontWeight.Bold)
            }
        } else {
            Text("OTP sent on WhatsApp to +${auth.phone}", color = Color.Gray)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = code, onValueChange = { code = it.filter(Char::isDigit).take(6) }, singleLine = true,
                modifier = Modifier.fillMaxWidth(), label = { Text("Enter 6-digit OTP") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
            )
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = { onVerify(code) }, enabled = !auth.busy && code.length >= 4,
                modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Navy)
            ) {
                if (auth.busy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp, color = Color.White)
                else Text("Verify & Login", fontWeight = FontWeight.Bold)
            }
            TextButton({ code = ""; onChangeNumber() }) { Text("Change number") }
        }

        auth.error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp)) }

        Spacer(Modifier.height(20.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            HorizontalDivider(Modifier.weight(1f)); Text("  or  ", color = Color.Gray); HorizontalDivider(Modifier.weight(1f))
        }
        Spacer(Modifier.height(20.dp))
        OutlinedButton(
            onClick = onTruecaller, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(14.dp)
        ) { Text("Continue with Truecaller", fontWeight = FontWeight.Bold) }

        Spacer(Modifier.weight(1f))
        if (isOtpDemo) Text("DEMO mode: use OTP 123456", fontSize = 11.sp, color = Color.Gray)
    }
}

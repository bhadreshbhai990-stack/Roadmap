package com.roadmap.app.ui

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.KeyboardOptions
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.roadmap.app.R
import com.roadmap.app.data.PdfReport
import com.roadmap.app.data.VehicleInfo

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoadMapApp(vm: AppViewModel = viewModel(), onTruecaller: () -> Unit = {}) {
    val phone by vm.phone.collectAsStateWithLifecycle()
    val auth by vm.auth.collectAsStateWithLifecycle()
    if (phone == null) {
        LoginScreen(auth, vm::sendOtp, vm::verifyOtp, vm::resetOtp, onTruecaller)
        return
    }
    val saved by vm.saved.collectAsStateWithLifecycle()
    val state by vm.state.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var detail by remember { mutableStateOf<VehicleInfo?>(null) }

    detail?.let { v ->
        BackHandler { detail = null }
        val isSaved = saved.any { it.regNo == v.regNo }
        DetailScreen(v, isSaved, onBack = { detail = null }, onToggleSave = { vm.toggleSave(v, isSaved) })
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(painterResource(R.drawable.ic_logo_fg), null, Modifier.size(36.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Road Map", fontWeight = FontWeight.Bold)
                    }
                },
                actions = { IconButton(vm::logout) { Icon(Icons.AutoMirrored.Filled.Logout, "Log out") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Navy, titleContentColor = Color.White, actionIconContentColor = Color.White)
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(tab == 0, { tab = 0 }, { Icon(Icons.Default.Search, null) }, label = { Text("Search") })
                NavigationBarItem(tab == 1, { tab = 1 }, { Icon(Icons.Default.Bookmarks, null) }, label = { Text("Saved") })
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize().background(Bg)) {
            if (tab == 0) SearchTab(state, onSearch = { q -> vm.search(q) { detail = it } })
            else SavedTab(saved, onOpen = { detail = it }, onDelete = { vm.toggleSave(it, true) })
        }
    }
}

@Composable
private fun Image(painter: androidx.compose.ui.graphics.painter.Painter, cd: String?, modifier: Modifier) =
    androidx.compose.foundation.Image(painter, cd, modifier)

@Composable
fun SearchTab(state: SearchState, onSearch: (String) -> Unit) {
    var q by rememberSaveable { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(24.dp))
        Text("Check vehicle details", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Navy)
        Text("Enter a vehicle number to get registration, fuel, class and validity details.", color = Color.Gray, modifier = Modifier.padding(vertical = 8.dp))
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = q, onValueChange = { q = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            label = { Text("Vehicle number (GJ05AB1234)") },
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
            isError = state.error != null, supportingText = { state.error?.let { Text(it) } }
        )
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = { onSearch(q) }, enabled = !state.loading,
            modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Color.Black)
        ) {
            if (state.loading) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
            else Text("Search", fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.weight(1f))
        Text("Not affiliated with any government authority. Information is for reference only.", fontSize = 11.sp, color = Color.Gray)
    }
}

@Composable
fun SavedTab(list: List<VehicleInfo>, onOpen: (VehicleInfo) -> Unit, onDelete: (VehicleInfo) -> Unit) {
    if (list.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("No saved vehicles yet", color = Color.Gray) }
        return
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items(list, key = { it.regNo }) { v ->
            Card(Modifier.fillMaxWidth().clickable { onOpen(v) }, shape = RoundedCornerShape(14.dp)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(v.regNo, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Navy)
                        Text(v.makerModel, color = Color.Gray)
                    }
                    IconButton({ onDelete(v) }) { Icon(Icons.Default.Delete, "Remove") }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(v: VehicleInfo, isSaved: Boolean, onBack: () -> Unit, onToggleSave: () -> Unit) {
    val ctx = LocalContext.current
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(v.regNo, fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                actions = {
                    IconButton(onToggleSave) {
                        Icon(if (isSaved) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, "Save")
                    }
                    IconButton({
                        val f = PdfReport.create(ctx, v)
                        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
                        ctx.startActivity(Intent.createChooser(
                            Intent(Intent.ACTION_SEND).setType("application/pdf")
                                .putExtra(Intent.EXTRA_STREAM, uri)
                                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Share PDF report"))
                    }) { Icon(Icons.Default.PictureAsPdf, "PDF") }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Navy, titleContentColor = Color.White,
                    navigationIconContentColor = Color.White, actionIconContentColor = Color.White)
            )
        }
    ) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize().background(Bg), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            val rows = listOf(
                "Owner" to v.ownerName, "Maker / Model" to v.makerModel, "Vehicle class" to v.vehicleClass,
                "Fuel type" to v.fuelType, "Registration date" to v.registrationDate, "RTO office" to v.rtoOffice,
                "Insurance valid upto" to v.insuranceUpto, "Fitness valid upto" to v.fitnessUpto,
                "PUC valid upto" to v.pucUpto, "Gross weight" to v.grossWeight
            )
            items(rows) { (k, x) ->
                Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                    Column(Modifier.padding(14.dp)) {
                        Text(k, fontSize = 12.sp, color = Color.Gray)
                        Text(x, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }
    }
}

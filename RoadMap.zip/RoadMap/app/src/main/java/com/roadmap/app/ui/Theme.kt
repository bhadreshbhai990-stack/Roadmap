package com.roadmap.app.ui

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Navy = Color(0xFF0B3D91)
val Amber = Color(0xFFFFB300)
val Bg = Color(0xFFF5F7FB)

@Composable
fun RoadMapTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(primary = Navy, secondary = Amber, background = Bg, surface = Color.White),
        content = content
    )
}

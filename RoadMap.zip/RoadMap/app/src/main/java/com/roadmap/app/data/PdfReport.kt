package com.roadmap.app.data

import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import java.io.File

object PdfReport {
    fun create(ctx: Context, v: VehicleInfo): File {
        val doc = PdfDocument()
        val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
        val c = page.canvas
        val bar = Paint().apply { color = Color.parseColor("#0B3D91") }
        c.drawRect(0f, 0f, 595f, 90f, bar)
        val title = Paint().apply { color = Color.WHITE; textSize = 26f; isFakeBoldText = true }
        c.drawText("Road Map", 32f, 50f, title)
        val sub = Paint().apply { color = Color.parseColor("#FFB300"); textSize = 13f }
        c.drawText("Vehicle Report", 32f, 72f, sub)

        val big = Paint().apply { color = Color.BLACK; textSize = 24f; isFakeBoldText = true }
        c.drawText(v.regNo, 32f, 140f, big)

        val label = Paint().apply { color = Color.GRAY; textSize = 12f }
        val value = Paint().apply { color = Color.BLACK; textSize = 15f }
        var y = 185f
        listOf(
            "Owner" to v.ownerName, "Maker / Model" to v.makerModel, "Vehicle class" to v.vehicleClass,
            "Fuel type" to v.fuelType, "Registration date" to v.registrationDate, "RTO office" to v.rtoOffice,
            "Insurance valid upto" to v.insuranceUpto, "Fitness valid upto" to v.fitnessUpto,
            "PUC valid upto" to v.pucUpto, "Gross weight" to v.grossWeight
        ).forEach { (k, x) ->
            c.drawText(k, 32f, y, label); c.drawText(x, 32f, y + 18f, value); y += 52f
        }
        val foot = Paint().apply { color = Color.GRAY; textSize = 10f }
        c.drawText("For information only. Not affiliated with any government authority.", 32f, 815f, foot)
        doc.finishPage(page)

        val dir = File(ctx.cacheDir, "reports").apply { mkdirs() }
        val file = File(dir, "RoadMap_${v.regNo}.pdf")
        file.outputStream().use { doc.writeTo(it) }
        doc.close()
        return file
    }
}

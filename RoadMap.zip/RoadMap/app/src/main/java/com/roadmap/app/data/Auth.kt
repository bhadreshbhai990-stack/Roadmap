package com.roadmap.app.data

import com.roadmap.app.BuildConfig
import kotlinx.coroutines.delay
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST

interface OtpProvider {
    suspend fun send(phone: String): Result<Unit>
    suspend fun verify(phone: String, code: String): Result<Unit>
}

/** DEMO: no backend needed. OTP is always 123456. */
object DemoOtp : OtpProvider {
    override suspend fun send(phone: String): Result<Unit> { delay(600); return Result.success(Unit) }
    override suspend fun verify(phone: String, code: String): Result<Unit> {
        delay(400)
        return if (code == "123456") Result.success(Unit) else Result.failure(IllegalArgumentException("bad otp"))
    }
}

private interface OtpApi {
    @POST("auth/whatsapp/send") suspend fun send(@Body b: Map<String, String>): Response<Unit>
    @POST("auth/whatsapp/verify") suspend fun verify(@Body b: Map<String, String>): Response<Unit>
}

/**
 * Talks to YOUR backend. The backend sends the OTP through the WhatsApp Business Cloud API
 * (authentication template) and checks it. Never put the WhatsApp token inside the app.
 */
object ApiOtp : OtpProvider {
    private val api: OtpApi by lazy {
        Retrofit.Builder().baseUrl(BuildConfig.OTP_BASE_URL)
            .addConverterFactory(GsonConverterFactory.create()).build().create(OtpApi::class.java)
    }
    override suspend fun send(phone: String) = runCatching { check(api.send(mapOf("phone" to phone)).isSuccessful) }
    override suspend fun verify(phone: String, code: String) =
        runCatching { check(api.verify(mapOf("phone" to phone, "code" to code)).isSuccessful) }
}

fun otpProvider(): OtpProvider = if (BuildConfig.OTP_BASE_URL.isBlank()) DemoOtp else ApiOtp
val isOtpDemo: Boolean get() = BuildConfig.OTP_BASE_URL.isBlank()

/** 10-digit numbers get +91 (India). Otherwise 11-15 digits with country code. */
fun normalizePhone(raw: String): String? {
    val d = raw.filter { it.isDigit() }
    return when {
        d.length == 10 -> "91$d"
        d.length in 11..15 -> d
        else -> null
    }
}
